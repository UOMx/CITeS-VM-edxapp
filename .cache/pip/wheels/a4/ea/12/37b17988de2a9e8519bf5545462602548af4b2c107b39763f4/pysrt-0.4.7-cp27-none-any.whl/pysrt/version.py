VERSION = (0, 4, 7)
VERSION_STRING = '.'.join(str(i) for i in VERSION)
