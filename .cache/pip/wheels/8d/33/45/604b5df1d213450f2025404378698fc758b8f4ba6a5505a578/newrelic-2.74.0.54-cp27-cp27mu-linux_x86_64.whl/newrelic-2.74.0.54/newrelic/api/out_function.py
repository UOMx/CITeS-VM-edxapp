# Use of these from this module will be deprecated.

from ..common.object_wrapper import (out_function, OutFunctionWrapper,
        wrap_out_function)
