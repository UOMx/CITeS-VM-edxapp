__version__ = '0.10.0'

__author__ = "Massimiliano Pippi & Federico Frenguelli"

default_app_config = 'oauth2_provider.apps.DOTConfig'

VERSION = __version__  # synonym
