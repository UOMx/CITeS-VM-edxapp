"""The lazy module."""

from __future__ import absolute_import
from .lazy import lazy
