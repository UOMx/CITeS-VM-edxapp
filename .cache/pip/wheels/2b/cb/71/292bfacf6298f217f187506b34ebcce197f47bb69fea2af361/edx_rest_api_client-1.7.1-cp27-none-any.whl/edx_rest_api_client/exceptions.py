# noinspection PyUnresolvedReferences
from requests.exceptions import Timeout  # pylint: disable=unused-import
from slumber.exceptions import *  # pylint: disable=wildcard-import
