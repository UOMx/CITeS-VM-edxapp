from .models import cloudformation_backend
mock_cloudformation = cloudformation_backend.decorator
