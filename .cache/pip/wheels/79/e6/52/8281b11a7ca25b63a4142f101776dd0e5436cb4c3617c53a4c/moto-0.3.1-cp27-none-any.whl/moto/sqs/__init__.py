from .models import sqs_backend
mock_sqs = sqs_backend.decorator
