VERSION = (2, 2, 8)  # PEP 386
__version__ = ".".join([str(x) for x in VERSION])
