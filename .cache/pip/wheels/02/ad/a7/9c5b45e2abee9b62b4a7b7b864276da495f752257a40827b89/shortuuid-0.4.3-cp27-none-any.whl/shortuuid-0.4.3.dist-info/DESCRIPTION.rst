A library that generates short, pretty, unambiguous unique IDs by using an extensive, case-sensitive alphabet and omitting similar-looking letters and numbers.


