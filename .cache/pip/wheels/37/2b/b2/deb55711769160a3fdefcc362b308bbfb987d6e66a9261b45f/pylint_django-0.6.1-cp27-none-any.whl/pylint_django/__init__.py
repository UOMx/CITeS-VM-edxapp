"""pylint_django module."""
from __future__ import absolute_import
from pylint_django import plugin

register = plugin.register
